from django.apps import AppConfig

class PatientsDiagnosesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'patients_diagnoses'
