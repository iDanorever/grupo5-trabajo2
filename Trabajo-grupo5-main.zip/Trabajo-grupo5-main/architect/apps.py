from django.apps import AppConfig


class ArchitectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'architect'