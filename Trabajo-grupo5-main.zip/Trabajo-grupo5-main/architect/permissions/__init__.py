from .custom import IsAdminUser, IsOwnerOrReadOnly

__all__ = ['IsAdminUser', 'IsOwnerOrReadOnly'] 