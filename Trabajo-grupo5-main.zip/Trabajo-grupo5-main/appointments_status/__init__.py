# Importar signals para que se registren automáticamente
default_app_config = 'appointments_status.apps.AppointmentsStatusConfig'
