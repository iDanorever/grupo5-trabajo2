# Serializers package
from .therapist import TherapistSerializer

__all__ = [
    'TherapistSerializer'
]
