# Tests para el módulo 02_users_profiles
