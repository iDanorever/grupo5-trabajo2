"""
Módulo 02_users_profiles - Gestión de Perfiles de Usuario
"""

# Comentado temporalmente para evitar problemas con pytest
# from .models import User, UserProfile, UserVerificationCode
# __all__ = ['User', 'UserProfile', 'UserVerificationCode']
